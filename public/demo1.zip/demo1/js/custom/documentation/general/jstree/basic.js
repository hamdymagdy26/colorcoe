/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./resources/assets/core/js/custom/documentation/general/jstree/basic.js":
/*!*******************************************************************************!*\
  !*** ./resources/assets/core/js/custom/documentation/general/jstree/basic.js ***!
  \*******************************************************************************/
/***/ (() => {

eval(" // Class definition\n\nvar KTJSTreeBasic = function () {\n  // Private functions\n  var exampleBasic = function exampleBasic() {\n    $('#kt_docs_jstree_basic').jstree({\n      \"core\": {\n        \"themes\": {\n          \"responsive\": false\n        }\n      },\n      \"types\": {\n        \"default\": {\n          \"icon\": \"fa fa-folder\"\n        },\n        \"file\": {\n          \"icon\": \"fa fa-file\"\n        }\n      },\n      \"plugins\": [\"types\"]\n    });\n  };\n\n  return {\n    // Public Functions\n    init: function init() {\n      exampleBasic();\n    }\n  };\n}(); // On document ready\n\n\nKTUtil.onDOMContentLoaded(function () {\n  KTJSTreeBasic.init();\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9yZXNvdXJjZXMvYXNzZXRzL2NvcmUvanMvY3VzdG9tL2RvY3VtZW50YXRpb24vZ2VuZXJhbC9qc3RyZWUvYmFzaWMuanMuanMiLCJtYXBwaW5ncyI6IkNBRUE7O0FBQ0EsSUFBSUEsYUFBYSxHQUFHLFlBQVc7RUFDM0I7RUFDQSxJQUFJQyxZQUFZLEdBQUcsU0FBZkEsWUFBZSxHQUFXO0lBQzFCQyxDQUFDLENBQUMsdUJBQUQsQ0FBRCxDQUEyQkMsTUFBM0IsQ0FBa0M7TUFDOUIsUUFBUztRQUNMLFVBQVc7VUFDUCxjQUFjO1FBRFA7TUFETixDQURxQjtNQU05QixTQUFVO1FBQ04sV0FBWTtVQUNSLFFBQVM7UUFERCxDQUROO1FBSU4sUUFBUztVQUNMLFFBQVM7UUFESjtNQUpILENBTm9CO01BYzlCLFdBQVcsQ0FBQyxPQUFEO0lBZG1CLENBQWxDO0VBZ0JILENBakJEOztFQW1CQSxPQUFPO0lBQ0g7SUFDQUMsSUFBSSxFQUFFLGdCQUFXO01BQ2JILFlBQVk7SUFDZjtFQUpFLENBQVA7QUFNSCxDQTNCbUIsRUFBcEIsQyxDQTZCQTs7O0FBQ0FJLE1BQU0sQ0FBQ0Msa0JBQVAsQ0FBMEIsWUFBVztFQUNqQ04sYUFBYSxDQUFDSSxJQUFkO0FBQ0gsQ0FGRCIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL3Jlc291cmNlcy9hc3NldHMvY29yZS9qcy9jdXN0b20vZG9jdW1lbnRhdGlvbi9nZW5lcmFsL2pzdHJlZS9iYXNpYy5qcz84M2Y2Il0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHN0cmljdFwiO1xyXG5cclxuLy8gQ2xhc3MgZGVmaW5pdGlvblxyXG52YXIgS1RKU1RyZWVCYXNpYyA9IGZ1bmN0aW9uKCkge1xyXG4gICAgLy8gUHJpdmF0ZSBmdW5jdGlvbnNcclxuICAgIHZhciBleGFtcGxlQmFzaWMgPSBmdW5jdGlvbigpIHtcclxuICAgICAgICAkKCcja3RfZG9jc19qc3RyZWVfYmFzaWMnKS5qc3RyZWUoe1xyXG4gICAgICAgICAgICBcImNvcmVcIiA6IHtcclxuICAgICAgICAgICAgICAgIFwidGhlbWVzXCIgOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgXCJyZXNwb25zaXZlXCI6IGZhbHNlXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIFwidHlwZXNcIiA6IHtcclxuICAgICAgICAgICAgICAgIFwiZGVmYXVsdFwiIDoge1xyXG4gICAgICAgICAgICAgICAgICAgIFwiaWNvblwiIDogXCJmYSBmYS1mb2xkZXJcIlxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIFwiZmlsZVwiIDoge1xyXG4gICAgICAgICAgICAgICAgICAgIFwiaWNvblwiIDogXCJmYSBmYS1maWxlXCJcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgXCJwbHVnaW5zXCI6IFtcInR5cGVzXCJdXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICAvLyBQdWJsaWMgRnVuY3Rpb25zXHJcbiAgICAgICAgaW5pdDogZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgICAgIGV4YW1wbGVCYXNpYygpO1xyXG4gICAgICAgIH1cclxuICAgIH07XHJcbn0oKTtcclxuXHJcbi8vIE9uIGRvY3VtZW50IHJlYWR5XHJcbktUVXRpbC5vbkRPTUNvbnRlbnRMb2FkZWQoZnVuY3Rpb24oKSB7XHJcbiAgICBLVEpTVHJlZUJhc2ljLmluaXQoKTtcclxufSk7XHJcbiJdLCJuYW1lcyI6WyJLVEpTVHJlZUJhc2ljIiwiZXhhbXBsZUJhc2ljIiwiJCIsImpzdHJlZSIsImluaXQiLCJLVFV0aWwiLCJvbkRPTUNvbnRlbnRMb2FkZWQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./resources/assets/core/js/custom/documentation/general/jstree/basic.js\n");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval-source-map devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./resources/assets/core/js/custom/documentation/general/jstree/basic.js"]();
/******/ 	
/******/ })()
;