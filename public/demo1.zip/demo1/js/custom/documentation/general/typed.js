/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./resources/assets/core/js/custom/documentation/general/typed.js":
/*!************************************************************************!*\
  !*** ./resources/assets/core/js/custom/documentation/general/typed.js ***!
  \************************************************************************/
/***/ (() => {

eval(" // Class definition\n\nvar KTGeneralTypedJsDemos = function () {\n  // Private functions\n  var exampleBasic = function exampleBasic() {\n    var typed = new Typed(\"#kt_typedjs_example_1\", {\n      strings: [\"First sentence.\", \"Second sentence.\", \"Third sentense\", \"And some longer sentence\"],\n      typeSpeed: 30\n    });\n  };\n\n  return {\n    // Public Functions\n    init: function init() {\n      exampleBasic();\n    }\n  };\n}(); // On document ready\n\n\nKTUtil.onDOMContentLoaded(function () {\n  KTGeneralTypedJsDemos.init();\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9yZXNvdXJjZXMvYXNzZXRzL2NvcmUvanMvY3VzdG9tL2RvY3VtZW50YXRpb24vZ2VuZXJhbC90eXBlZC5qcy5qcyIsIm1hcHBpbmdzIjoiQ0FFQTs7QUFDQSxJQUFJQSxxQkFBcUIsR0FBRyxZQUFXO0VBQ25DO0VBQ0EsSUFBSUMsWUFBWSxHQUFHLFNBQWZBLFlBQWUsR0FBVztJQUMxQixJQUFJQyxLQUFLLEdBQUcsSUFBSUMsS0FBSixDQUFVLHVCQUFWLEVBQW1DO01BQzNDQyxPQUFPLEVBQUUsQ0FBQyxpQkFBRCxFQUFvQixrQkFBcEIsRUFBd0MsZ0JBQXhDLEVBQTBELDBCQUExRCxDQURrQztNQUUzQ0MsU0FBUyxFQUFFO0lBRmdDLENBQW5DLENBQVo7RUFJSCxDQUxEOztFQU9BLE9BQU87SUFDSDtJQUNBQyxJQUFJLEVBQUUsZ0JBQVc7TUFDYkwsWUFBWTtJQUNmO0VBSkUsQ0FBUDtBQU1ILENBZjJCLEVBQTVCLEMsQ0FpQkE7OztBQUNBTSxNQUFNLENBQUNDLGtCQUFQLENBQTBCLFlBQVc7RUFDakNSLHFCQUFxQixDQUFDTSxJQUF0QjtBQUNILENBRkQiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9yZXNvdXJjZXMvYXNzZXRzL2NvcmUvanMvY3VzdG9tL2RvY3VtZW50YXRpb24vZ2VuZXJhbC90eXBlZC5qcz84Mzk2Il0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHN0cmljdFwiO1xyXG5cclxuLy8gQ2xhc3MgZGVmaW5pdGlvblxyXG52YXIgS1RHZW5lcmFsVHlwZWRKc0RlbW9zID0gZnVuY3Rpb24oKSB7XHJcbiAgICAvLyBQcml2YXRlIGZ1bmN0aW9uc1xyXG4gICAgdmFyIGV4YW1wbGVCYXNpYyA9IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIHZhciB0eXBlZCA9IG5ldyBUeXBlZChcIiNrdF90eXBlZGpzX2V4YW1wbGVfMVwiLCB7XHJcbiAgICAgICAgICAgIHN0cmluZ3M6IFtcIkZpcnN0IHNlbnRlbmNlLlwiLCBcIlNlY29uZCBzZW50ZW5jZS5cIiwgXCJUaGlyZCBzZW50ZW5zZVwiLCBcIkFuZCBzb21lIGxvbmdlciBzZW50ZW5jZVwiXSxcclxuICAgICAgICAgICAgdHlwZVNwZWVkOiAzMFxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgLy8gUHVibGljIEZ1bmN0aW9uc1xyXG4gICAgICAgIGluaXQ6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICBleGFtcGxlQmFzaWMoKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG59KCk7XHJcblxyXG4vLyBPbiBkb2N1bWVudCByZWFkeVxyXG5LVFV0aWwub25ET01Db250ZW50TG9hZGVkKGZ1bmN0aW9uKCkge1xyXG4gICAgS1RHZW5lcmFsVHlwZWRKc0RlbW9zLmluaXQoKTtcclxufSk7XHJcbiJdLCJuYW1lcyI6WyJLVEdlbmVyYWxUeXBlZEpzRGVtb3MiLCJleGFtcGxlQmFzaWMiLCJ0eXBlZCIsIlR5cGVkIiwic3RyaW5ncyIsInR5cGVTcGVlZCIsImluaXQiLCJLVFV0aWwiLCJvbkRPTUNvbnRlbnRMb2FkZWQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./resources/assets/core/js/custom/documentation/general/typed.js\n");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval-source-map devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./resources/assets/core/js/custom/documentation/general/typed.js"]();
/******/ 	
/******/ })()
;