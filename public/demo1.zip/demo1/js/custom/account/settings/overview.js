/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./resources/assets/core/js/custom/account/settings/overview.js":
/*!**********************************************************************!*\
  !*** ./resources/assets/core/js/custom/account/settings/overview.js ***!
  \**********************************************************************/
/***/ (() => {

eval(" // Class definition\n\nvar KTAccountSettingsOverview = function () {\n  // Private functions\n  var initSettings = function initSettings() {}; // Public methods\n\n\n  return {\n    init: function init() {\n      initSettings();\n    }\n  };\n}(); // On document ready\n\n\nKTUtil.onDOMContentLoaded(function () {\n  KTAccountSettingsOverview.init();\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9yZXNvdXJjZXMvYXNzZXRzL2NvcmUvanMvY3VzdG9tL2FjY291bnQvc2V0dGluZ3Mvb3ZlcnZpZXcuanMuanMiLCJtYXBwaW5ncyI6IkNBRUE7O0FBQ0EsSUFBSUEseUJBQXlCLEdBQUcsWUFBWTtFQUN4QztFQUNBLElBQUlDLFlBQVksR0FBRyxTQUFmQSxZQUFlLEdBQVcsQ0FFN0IsQ0FGRCxDQUZ3QyxDQU14Qzs7O0VBQ0EsT0FBTztJQUNIQyxJQUFJLEVBQUUsZ0JBQVk7TUFDZEQsWUFBWTtJQUNmO0VBSEUsQ0FBUDtBQUtILENBWitCLEVBQWhDLEMsQ0FjQTs7O0FBQ0FFLE1BQU0sQ0FBQ0Msa0JBQVAsQ0FBMEIsWUFBVztFQUNqQ0oseUJBQXlCLENBQUNFLElBQTFCO0FBQ0gsQ0FGRCIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL3Jlc291cmNlcy9hc3NldHMvY29yZS9qcy9jdXN0b20vYWNjb3VudC9zZXR0aW5ncy9vdmVydmlldy5qcz83NDg5Il0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHN0cmljdFwiO1xyXG5cclxuLy8gQ2xhc3MgZGVmaW5pdGlvblxyXG52YXIgS1RBY2NvdW50U2V0dGluZ3NPdmVydmlldyA9IGZ1bmN0aW9uICgpIHtcclxuICAgIC8vIFByaXZhdGUgZnVuY3Rpb25zXHJcbiAgICB2YXIgaW5pdFNldHRpbmdzID0gZnVuY3Rpb24oKSB7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIC8vIFB1YmxpYyBtZXRob2RzXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGluaXQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgaW5pdFNldHRpbmdzKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59KCk7XHJcblxyXG4vLyBPbiBkb2N1bWVudCByZWFkeVxyXG5LVFV0aWwub25ET01Db250ZW50TG9hZGVkKGZ1bmN0aW9uKCkge1xyXG4gICAgS1RBY2NvdW50U2V0dGluZ3NPdmVydmlldy5pbml0KCk7XHJcbn0pO1xyXG4iXSwibmFtZXMiOlsiS1RBY2NvdW50U2V0dGluZ3NPdmVydmlldyIsImluaXRTZXR0aW5ncyIsImluaXQiLCJLVFV0aWwiLCJvbkRPTUNvbnRlbnRMb2FkZWQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./resources/assets/core/js/custom/account/settings/overview.js\n");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval-source-map devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./resources/assets/core/js/custom/account/settings/overview.js"]();
/******/ 	
/******/ })()
;